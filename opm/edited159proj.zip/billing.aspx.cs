﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web.Configuration;

public partial class _Default : System.Web.UI.Page
{
    string conString = ConfigurationManager.ConnectionStrings["ConnStringDb1"].ConnectionString;
    private static int visitCounter = 0; 
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox3.Text = DateTime.Now.ToString("dd-MM-yyyy");

        TextBox2.Text = Session["PN"].ToString();
        visitCounter++; // Increase each time a form is loaded
        TextBox1.Text = visitCounter.ToString("0000"); 
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(conString);
        con.Open();
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "insert into sales values('" + TextBox1.Text + "','" + TextBox6.Text + "','" + TextBox2.Text + "', '"+ TextBox4.Text +"','"+ TextBox3.Text +"', '"+ TextBox5.Text +"') ";
        
        string script = "alert('Submitted successfully !');";
        ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", script, true);
        cmd.ExecuteNonQuery();
    }
   
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox5_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox6_TextChanged(object sender, EventArgs e)
    {
       
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
}