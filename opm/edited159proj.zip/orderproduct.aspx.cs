﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    private static int Counter = 0; 
    public void Button3_Click(object sender, EventArgs e)
    {
        string po = checkboxlistItem1.SelectedItem.Text;
        string z;
        Counter++;
        z = Counter.ToString("1000");
        Session["id"] = z;

        switch (po)
        {
            case ("ASUS"):
                
                String a = "ASUS";
                Session["ProdName"] = a;
                Response.Redirect("placeorder.aspx");
                break;

            case ("G6"):
                String b = "G6";
                Session["ProdName"] = b;
                Response.Redirect("placeorder.aspx");
                break;

            case ("GIONEE"):
                String c = "GIONEE";
                Session["ProdName"] = c;
                Response.Redirect("placeorder.aspx");
                break;

            case ("SONY"):
                String d = "SONY";
                Session["ProdName"] = d;
                Response.Redirect("placeorder.aspx");
                break;

            case ("MICROMAX"):
                String f = "MICROMAX";
                Session["ProdName"] = f;
                Response.Redirect("placeorder.aspx");
                break;

            case ("IPHONE"):
                String g = "IPHONE";
                Session["ProdName"] = g;
                Response.Redirect("placeorder.aspx");
                break;
            default:
                Console.WriteLine("CHOOSE ATLEAST ONE CHECK BOX");
                break;
        }
    }
}
