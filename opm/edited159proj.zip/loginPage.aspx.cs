﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web.Configuration;


public partial class loginPage : System.Web.UI.Page
{
    //string strcon = "Data Source=LAPTOP-MRF0995H;Integrated Security=True;database=JNGROUPS";
    string conString = ConfigurationManager.ConnectionStrings["ConnStringDb1"].ConnectionString;

    protected void ButtonSubmit_Click(object sender, EventArgs e)
    {
       
        SqlConnection con = new SqlConnection(conString);
        con.Open();
        SqlCommand com = new SqlCommand("CheckUser", con);
        com.CommandType = CommandType.StoredProcedure;
        SqlParameter p1 = new SqlParameter("username", TextBox3.Text);
        SqlParameter p2 = new SqlParameter("password", TextBox4.Text);
        com.Parameters.Add(p1);
        com.Parameters.Add(p2);
        SqlDataReader rd = com.ExecuteReader();
        try
        {

            if (rd.HasRows)
            {
                Response.Redirect("home.aspx");
            }
        }
        catch (SqlException sql)
        {
            Response.Redirect("loginPage.aspx");
        }

        con.Close();
       
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("loginPage.aspx");

    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}