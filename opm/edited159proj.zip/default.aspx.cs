﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



public partial class productavailability : System.Web.UI.Page
{
    protected void Button1_Click(object sender, EventArgs e)
    {
        string li = checkboxlistItem.SelectedItem.Text;
        switch (li)
        {
            case ("ASUS"):
                String a = "ASUS";
                Session["PN"] = a;
                Response.Redirect("billing.aspx");
                break;

            case ("G6"):
                String b = "G6";
                Session["PN"] = b;
                Response.Redirect("billing.aspx");
                break;

            case ("GIONEE"):
                String c = "GIONEE";
                Session["PN"] = c;
                Response.Redirect("billing.aspx");
                break;

            case ("SONY"):
                String d = "SONY";
                Session["PN"] = d;
                Response.Redirect("billing.aspx");
                break;

            case ("MICROMAX"):
                String f = "MICROMAX";
                Session["PN"] = f;
                Response.Redirect("billing.aspx");
                break;

            case ("IPHONE"):
                String g = "IPHONE";
                Session["PN"] = g;
                Response.Redirect("billing.aspx");
                break;
            default:
                Console.WriteLine("CHOOSE ATLEAST ONE CHECK BOX");
                break;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
                    Response.Redirect("orderproduct.aspx");
    }
}